package com.cleardialer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService

/**
 * Receives calls from the system. This app shows its own call screen and
 * never takes the proximity wake lock, so the screen never turns off at your ear.
 */
class DialerInCallService : InCallService() {

    private val cb = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) = refresh()
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_IN, "Incoming calls", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ONGOING, "Ongoing calls", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        callAudioState?.let { CallManager.onAudio(it) }
        CallManager.add(call)
        call.registerCallback(cb)
        refresh()
        if (call.state != Call.STATE_RINGING) {
            startActivity(
                Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        call.unregisterCallback(cb)
        CallManager.remove(call)
        refresh()
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        CallManager.onAudio(audioState)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        CallManager.service = null
        return super.onUnbind(intent)
    }

    private fun refresh() {
        val nm = getSystemService(NotificationManager::class.java)
        val c = CallManager.current
        if (c == null) {
            nm.cancel(NOTIF_ID)
            return
        }
        val number = c.details.handle?.schemeSpecificPart ?: ""
        val title = Contacts.lookup(this, number) ?: number.ifBlank { "Unknown" }
        val ringing = c.state == Call.STATE_RINGING
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = Notification.Builder(this, if (ringing) CH_IN else CH_ONGOING)
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setContentTitle(title)
            .setContentText(if (ringing) "Incoming call" else "Ongoing call")
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(open)
        if (ringing) builder.setFullScreenIntent(open, true)
        nm.notify(NOTIF_ID, builder.build())
    }

    companion object {
        private const val CH_IN = "incoming"
        private const val CH_ONGOING = "ongoing"
        private const val NOTIF_ID = 42
    }
}
