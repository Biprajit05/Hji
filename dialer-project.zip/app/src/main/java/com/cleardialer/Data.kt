package com.cleardialer

import android.Manifest
import android.content.ContentResolver
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract

data class RecentCall(val number: String, val name: String?, val type: Int, val date: Long)

object CallLogRepo {
    fun load(ctx: Context): List<RecentCall> {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            return emptyList()
        }
        val out = ArrayList<RecentCall>()
        try {
            val args = Bundle().apply {
                putInt(ContentResolver.QUERY_ARG_LIMIT, 100)
                putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(CallLog.Calls.DATE))
                putInt(
                    ContentResolver.QUERY_ARG_SORT_DIRECTION,
                    ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                )
            }
            val projection = arrayOf(
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE
            )
            ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, projection, args, null)?.use { c ->
                while (c.moveToNext()) {
                    out.add(
                        RecentCall(
                            number = c.getString(0) ?: "",
                            name = c.getString(1)?.takeIf { it.isNotBlank() },
                            type = c.getInt(2),
                            date = c.getLong(3)
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}

object Contacts {
    fun lookup(ctx: Context, number: String): String? {
        if (number.isBlank()) return null
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                Uri.encode(number)
            )
            ctx.contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) {
            null
        }
    }
}
